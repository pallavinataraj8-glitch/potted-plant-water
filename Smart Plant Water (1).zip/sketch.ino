#include <WiFi.h>
#include <PubSubClient.h>
#include <ESP32Servo.h>

const char* BROKER = "broker.hivemq.com";
const char* TOPIC  = "pallavi/plantwaterer";   // must be SAME as Colab

WiFiClient espClient;
PubSubClient mqtt(espClient);
Servo canServo;
const int SERVO_PIN = 18;

void onMessage(char* topic, byte* payload, unsigned int len) {
  String msg = "";
  for (unsigned int i = 0; i < len; i++) msg += (char)payload[i];
  Serial.println("Got: " + msg);

  if (msg == "hello") {
    Serial.println("Hi!");
  }
  else if (msg == "water") {          // <-- the new block
    Serial.println("Plant seen, tilting can");
    canServo.write(90);
    delay(2000);
    canServo.write(0);
  }
}

void setup() {
  Serial.begin(115200);
  canServo.attach(SERVO_PIN);
  canServo.write(0);
  WiFi.begin("Wokwi-GUEST", "");
  while (WiFi.status() != WL_CONNECTED) {
    delay(300);
    Serial.print(".");
  }
  Serial.println("\nWiFi OK");
  mqtt.setServer(BROKER, 1883);
  mqtt.setCallback(onMessage);
}

void loop() {
  if (!mqtt.connected()) {
    String id = "esp32-" + String(random(9999));
    if (mqtt.connect(id.c_str())) {
      mqtt.subscribe(TOPIC);
      Serial.println("Listening on topic");
    } else {
      delay(1000);
      return;
    }
  }
  mqtt.loop();
}
